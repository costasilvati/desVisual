﻿using System;
namespace MyApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] stage = { "Certify", "Approved", "Evaluation" };
            Console.WriteLine(stage[1] + "!!");
        }
    }
}