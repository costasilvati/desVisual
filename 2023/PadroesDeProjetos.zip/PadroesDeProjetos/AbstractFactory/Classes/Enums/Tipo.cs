﻿using System;
using System.Collections.Generic;
using System.Text;


namespace AbstractFactory.Classes.Enums
{
    public enum Tipo
    {
        Express,
        Normal,
        Personalizado
    }
}
