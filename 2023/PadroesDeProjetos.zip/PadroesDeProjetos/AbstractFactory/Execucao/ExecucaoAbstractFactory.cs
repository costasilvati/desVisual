﻿using System;
using System.Collections.Generic;
using AbstractFactory.Classes.Entregas;
using AbstractFactory.Classes.Enums;

namespace AbstractFactory.Execucao
{
    public class ExecucaoAbstractFactory
    {
        public static void Executar()
        {
            List<Entrega> entregas = new List<Entrega>();
            {
                EntregaCreator.Criar("São Paulo", Tipo.Normal, " Tenis Adidas"),
                EntregaCreator.Criar("Lisboa ", Tipo.Express, " Tenis Nike"),
                EntregaCreator.Criar("Coimbra  ", Tipo.Personalizado, "  Tv 54")
            };

            entregas.ForEach(v => RealizarEntrega.RealizarEntregaProduto(v).RealizarAtendimentoEntrega());
        }
    }
}
