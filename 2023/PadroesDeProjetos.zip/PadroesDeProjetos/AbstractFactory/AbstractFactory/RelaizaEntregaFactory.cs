﻿using System;
using AbstractFactory.Classes.Pedidos;
using AbstractFactory.Classes.Entregas;

namespace AbstractFactory.AbstractFactory
{
    // Abstract Factory
    public abstract class RealizarEntregaFactory
    {
        public abstract Pedido CriarPedido();
        public abstract Entrega CriarEntrega(string localidade, Tipo tipo, string produto);
    }
}
