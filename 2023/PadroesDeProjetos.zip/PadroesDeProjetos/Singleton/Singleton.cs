﻿using System;
namespace Singleton
{
    //Quando aplicado a uma classe, o modificador sealed impede que outras classes herdem dela
    public sealed class Singleton
    {
        private string Message { get; }
        private Singleton() { }
        private static Singleton instance = null;

        public static Singleton Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new Singleton();
                }
                return instance;
            }
        }
    }
}
