﻿using System;

namespace Singleton
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Bem vindo ao padrão Singleton");
            Singleton s = Singleton.Instance;
            Console.WriteLine(nameof(s));
            Singleton s2 = Singleton.Instance;
            Console.WriteLine(nameof(s2));
            if (ReferenceEquals(s, s2))
            {
                Console.WriteLine("Mesma Instância!");
            }
            else
            {
                Console.WriteLine("Instancias diferenctes");
            }
        }
    }
}
