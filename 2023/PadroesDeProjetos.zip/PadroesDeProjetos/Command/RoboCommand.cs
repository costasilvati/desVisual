﻿using System;
namespace Command
{
    public abstract class RoboCommand
    {
        protected Robo _robo;

        public RoboCommand(Robo robo)
        {
            _robo = robo;
        }

        public abstract void Executar();
        public abstract void Desfazer();
    }
}
