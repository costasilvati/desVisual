﻿using System;
using System.Collections.Generic;

namespace Command
{
    public class RoboControle
    {
        public Queue<RoboCommand> Comandos;
        private Stack<RoboCommand> _desfazerPilha;

        public RoboControle()
        {
            Comandos = new Queue<RoboCommand>();
            _desfazerPilha = new Stack<RoboCommand>();
        }

        public void ExecutarComandos()
        {
            Console.WriteLine("Executando comandos....");

            while (Comandos.Count > 0)
            {
                RoboCommand command = Comandos.Dequeue();
                command.Executar();
                _desfazerPilha.Push(command);
            }
        }

        public void DesfazerComandos(int numComandos)
        {
            Console.WriteLine("Desfazendo" + numComandos + "comandos....");
            while(numComandos > 0 && _desfazerPilha.Count > 0)
            {
                RoboCommand command = _desfazerPilha.Pop();
                command.Desfazer();
                numComandos--;
            }
        }
    }
}
