﻿using System;
namespace Command
{
    public class Robo
    {
        public void Mover(int PraFrente)
        {
            if (PraFrente > 0)
            {
                Console.WriteLine("Robo andou pra frente {0}m ", PraFrente);
            }
            else
            {
                Console.WriteLine("Robo andou {0} para trás.", PraFrente);
            }
        }

        public void RotacionarParaEsquerda(double rotacionar)
        {
            if (rotacionar > 0)
            {
                Console.WriteLine("Robo foi rotacionado {0}m para esquerda", rotacionar);
            }
            else
            {
                Console.WriteLine("Robo foi rotacionado {0}m para direita", rotacionar);
            }
        }

        public void Escavar(bool paraCima)
        {
            if (paraCima)
            {
                Console.WriteLine("O robo coletou uma amostra");
            }
            else
            {
                Console.WriteLine("O robo escavou");
            }
        }
    }
}
