﻿using System;
namespace Command
{
    public class RotacionarCommand : RoboCommand
    {
        public double Rotacionar { get; set; }

        public RotacionarCommand(Robo robo) : base(robo) { }

        public override void Executar()
        {
            _robo.RotacionarParaEsquerda(Rotacionar);
        }

        public override void Desfazer()
        {
            _robo.RotacionarParaEsquerda(-Rotacionar);
        }
    }
}
