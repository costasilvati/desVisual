﻿using System;
namespace Command
{
    public class MoverCommand : RoboCommand
    {
        public int ParaFrente { get; set; }

        public MoverCommand(Robo robo) : base(robo) { }

        public override void Executar()
        {
            _robo.Mover(ParaFrente);
        }

        public override void Desfazer()
        {
            _robo.Mover(-ParaFrente);
        }
    }
}
