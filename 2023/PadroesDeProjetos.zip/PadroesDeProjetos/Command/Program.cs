﻿using System;

namespace Command
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            Robo robo = new Robo();
            RoboControle roboControle = new RoboControle();

            MoverCommand mover = new MoverCommand(robo);
            mover.ParaFrente = 100;
            roboControle.Comandos.Enqueue(mover);

            RotacionarCommand rotacionar = new RotacionarCommand(robo);
            rotacionar.Rotacionar = 45;
            roboControle.Comandos.Enqueue(rotacionar);

            EscavarCommand escavar = new EscavarCommand(robo);
            escavar.ColherMaterial = true;
            roboControle.Comandos.Enqueue(escavar);

            roboControle.ExecutarComandos();
            roboControle.DesfazerComandos(2);

        }
    }
}
