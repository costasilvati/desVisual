﻿namespace APIExemplo.Models
{
    public class ProdutoInputModel
    {
        public string Nome { get; set; }
        public int Quantidade { get; set; }
        public double Valor { get; set; }
    }

}
